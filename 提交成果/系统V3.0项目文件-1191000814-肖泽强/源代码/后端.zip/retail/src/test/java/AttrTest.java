import org.junit.Test;

public class AttrTest{

    @Test
    public void test(){

    }
}
