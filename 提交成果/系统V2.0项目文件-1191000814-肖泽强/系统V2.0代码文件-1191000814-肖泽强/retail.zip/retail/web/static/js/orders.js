//草稿页面的几个
var Draft_table;
var D_id;
var D_name;
var D_discount;
var D_num;
// table
var Show_Table;
// 增加草稿
var Add_draft;
function main(){
    Show_Table=document.getElementById("draft_table");
  

    Draft_table=document.getElementById("draft_table");
    D_id=document.getElementById("draft_id");
    D_name=document.getElementById("draft_name");
    D_discount=document.getElementById("draft_discount");
    D_num=document.getElementById("draft_num");
    // add
    Add_draft=document.getElementById("add_draft");
// //    打印
    query_craft("*");
    setEventListener();
}


function query_craft(name="*"){
    ajaxPost(
        'http://'+HOST+':8080/retail/order',
        'getAll',
        {"name":name},
        function(data){
            for(let i=0;i<data.length;i++){
                data[i]["goods"] = JSON.stringify(data[i]["goods"]);
                //三个按钮：删除、修改、审核
                appendJsonItemToTableWithButtons(
                Show_Table,
                data[i],
                ["id", "goods","createDate","imDate","price","customerId","profit"],
                [
                    CreateTableRowButton("删除", function(Row){
                        ajaxPost(
                            'http://'+HOST+':8080/retail/order',
                            'remove',
                            {"id":data[i]["id"]},
                            function(data){
                                clearTable(Show_Table);
                                // clear之后再重新打印一次
                                query_goods();
                            },
                            function(data){
                                // alert("删除失败...");
                                alert(data);
                            }
                        );
                    }),
                    CreateTableRowButton("修改",function(Row){
                        id_to_update=data[i]["id"];

                        Div_Update.style["display"]="inline";

                         // 设置其它行为默认颜色
                         console.log("123");
                         console.log(id_to_update);
                         console.log(last_Row_to_update);
                         if(last_Row_to_update !== null){
                             for(let i=0; i<last_Row_to_update.childNodes.length-1; i++){
                                 last_Row_to_update.childNodes[i].style["color"] = "#4f6b72";
                             }
                         }
                         // 设置选中的行为红色
                         for(let i=0; i<Row.childNodes.length-1; i++){
                             Row.childNodes[i].style["color"] = "red";
                         }
                         // 重新更新下一行的指针
                         last_Row_to_update = Row;
                    }),
                    
                    CreateTableRowButton("审核", function(Row){
                        ajaxPost(
                            'http://'+HOST+':8080/retail/order',
                            'confirm',
                            {"id":data[i]["id"]},
                            function(data){
                                alert("ok");
                                clearTable(Show_Table);
                                // clear之后再重新打印一次
                                query_goods();
                            },
                            function(data){
                                // alert("删除失败...");
                                alert(data);
                            }
                        );
                    })
                ]
                );
            }
        },
        function(data){
            alert(data);
        }
    
    );
}

function setEventListener(){
    Add_draft.addEventListener("click", function(){
        let draft_table = this.parentNode.childNodes[5];
        
        let customerId = document.getElementById("customer_name").value;
        let data_collected = [];
        for(let i=1; i<draft_table.rows.length; i++){
            console.log(draft_table.rows[i].cells[0].childNodes);
            data_collected.push({
                "goodsId": 1,
                "num":  Number(draft_table.rows[i].cells[1].childNodes[0].value),
                "discountRate": 1,
                "goodsName": draft_table.rows[i].cells[0].childNodes[0].value
            }
            


            );
            console.log({
                "goodItems":data_collected,
                "customerId":customerId
            });
        }

        ajaxPost(
            'http://'+HOST+':8080/retail/order',
            'add',
            {
                "goodItems":data_collected,
                "customerId":customerId
            }
            ,
            function(data){

            },
            function(data){
                alert(data);
            }
        );
        

    });
    // modify

    Update_submit.addEventListener('click',function(){
        let id=id_to_update;
     
        let update_tradePrice=Update_tradePrice["value"];
        let update_price=Update_price["value"];
        let update_cost=Update_cost["value"];
        // let update_submit=Update_submit["value"];
        Div_Update.style["display"]="inline";
        ajaxPost(
            'http://'+HOST+':8080/retail/order',
            'modify',
            {"id":id,"tradePrice":update_tradePrice,"price":update_price,"cost":update_cost},
            function(data){
                clearTable(Show_Table);
                query_goods("*");
                Div_Update.style["display"] = "none";
                // for(let i=0; i<Row.childNodes.length-1; i++){
                //     Row.childNodes[i].style["color"] = "4f6b72";
                // }
            },
            function(data){
                // alert(data);
                alert("123");
            }
        );
    });
}