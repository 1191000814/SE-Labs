package web;

import com.google.gson.Gson;
import pojo.*;
import service.OrderItemService;
import service.OrderService;
import utils.Utils;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

public class OrderServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");
        resp.setHeader("Access-Control-Allow-Origin", "*");
        // 这两个都需要设置,一个请求端,一个是回复端
        String action = req.getParameter("action");

        // 获取全部订单
        if(action.equals("getAll")){
            OrderService orderService = new OrderService();
            List<OrderVo> aList = orderService.getAll();
            List<FrontOrder> bList = Utils.ordersTran(aList);
            try {
                resp.getWriter().write(Result.resJson(true, bList));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // 增加一条订单
        if(action.equals("add")){
            OrderService orderService = new OrderService();
            OrderItemService orderItemService = new OrderItemService();
            String data = req.getParameter("data");
            FrontAdd frontAdd = new Gson().fromJson(data, FrontAdd.class);

            int customerId = frontAdd.getCustomerId();

            StringBuilder stringBuilder = new StringBuilder();
            List<FrontAddItem> addItems = frontAdd.getGoodItems();
            for(FrontAddItem addItem : addItems){
                int goodsId = addItem.getGoodsId();
                String goodsName = addItem.getGoodsName();
                int num = addItem.getNum();
                float discountRate = addItem.getDiscountRate();
                int orderItemId = orderItemService.add(goodsId, goodsName, num, discountRate);
                stringBuilder.append(orderItemId).append(" ");
            }
            String goods = stringBuilder.toString();

            orderService.addOrder(goods, customerId);
            try {
                resp.getWriter().write(Result.resJson(true, null));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // 确认一条订单
        if(action.equals("confirm")){
            OrderService orderService = new OrderService();
            String data = req.getParameter("data");
            //System.out.println(data);
            FrontId frontId = new Gson().fromJson(data, FrontId.class);
            orderService.confirm(frontId.getId());
            try {
                resp.getWriter().write(Result.resJson(true, null));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //修改一条订单
        if(action.equals("modify")){
            OrderService orderService = new OrderService();
            OrderItemService orderItemService = new OrderItemService();
            String data = req.getParameter("data");
            FrontModify frontModify = new Gson().fromJson(data, FrontModify.class);

            int id = frontModify.getId();
            int customerId = frontModify.getCustomerId();

            StringBuilder stringBuilder = new StringBuilder();
            List<FrontAddItem> addItems = frontModify.getGoodItems();
            for(FrontAddItem addItem : addItems){
                int goodsId = addItem.getGoodsId();
                String goodsName = addItem.getGoodsName();
                int num = addItem.getNum();
                float discountRate = addItem.getDiscountRate();
                int orderItemId = orderItemService.add(goodsId, goodsName, num, discountRate);
                stringBuilder.append(orderItemId).append(" ");
            }
            String goods = stringBuilder.toString();

            orderService.modify(goods, customerId, id);
            try {
                resp.getWriter().write(Result.resJson(true, null));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //删除一条订单
        if(action.equals("remove")){
            OrderService orderService = new OrderService();
            String data = req.getParameter("data");
            //System.out.println(data);
            FrontId frontId = new Gson().fromJson(data, FrontId.class);
            orderService.remove(frontId.getId());
            try {
                resp.getWriter().write(Result.resJson(true, null));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        doPost(req, resp);
    }
}
