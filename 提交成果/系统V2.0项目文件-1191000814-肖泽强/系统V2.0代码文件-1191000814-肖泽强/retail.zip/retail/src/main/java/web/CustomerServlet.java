package web;

import com.google.gson.Gson;
import pojo.Customer;
import pojo.Result;
import service.CustomerService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class CustomerServlet extends BaseServlet{

    Gson gson = new Gson();
    CustomerService customerService = new CustomerService();

    public void search(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        Customer customer = gson.fromJson(data, Customer.class);
        System.out.println("查询客户名称: " + customer.getName());
        List<Customer> infos;
        if(customer.getName().equals("*"))
            infos = customerService.getAll();
        else
            infos = customerService.search("*");
        boolean flag = infos.size() > 0;
        resp.getWriter().write(Result.resJson(flag, flag ? infos : "没有查询到任何结果"));
    }

    public void getAll(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        List<Customer> infos = customerService.getAll();
        boolean flag = infos.size() > 0;
        resp.getWriter().write(Result.resJson(flag, flag ? infos : "仓库里没有任何商品"));
    }

    public void add(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        Customer customer = gson.fromJson(data, Customer.class);
        boolean flag = customerService.add(customer);
        resp.getWriter().write(Result.resJson(flag, flag ? null : "添加失败"));
    }

    public void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        System.out.println("数据:" + data);
        Customer customer = gson.fromJson(data, Customer.class);
        System.out.println("要删除的客户id: " + customer.getId());
        boolean flag = customerService.delete(customer.getId());
        resp.getWriter().write(Result.resJson(flag, flag ? null : "删除失败"));
    }

    public void update(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        Customer customer = gson.fromJson(data, Customer.class);
        boolean flag = customerService.update(customer);
        resp.getWriter().write(Result.resJson(flag, flag ? null : "修改失败"));
    }
}
