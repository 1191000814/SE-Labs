package service;

import mapper.*;
import pojo.*;
import utils.MyBatisUtils;
import utils.Utils;

import java.util.Date;
import java.util.List;

public class OrderService {

    OrderMapper orderMapper = MyBatisUtils.getSqlSession().getMapper(OrderMapper.class);
    DraftOrderMapper draftOrderMapper = MyBatisUtils.getSqlSession().getMapper(DraftOrderMapper.class);
    OrderItemMapper orderItemMapper = MyBatisUtils.getSqlSession().getMapper(OrderItemMapper.class);
    static GoodsMapper goodsMapper = MyBatisUtils.getSqlSession().getMapper(GoodsMapper.class);
    static CustomerMapper customerMapper = MyBatisUtils.getSqlSession().getMapper(CustomerMapper.class);

    public void addOrder(String goods, int customerId){
        Date date = new Date();
        float price = 0;
        float cost = 0;
        //System.out.println(goods);
        List<Integer> aList = Utils.getItemsIdFromGoods(goods);
        for(Integer i : aList){
            OrderItemVo orderItemVo = orderItemMapper.getById(i);
            float price_temp = getPriceOfOrderItem(orderItemVo, customerId);
            float cost_temp = getCostOfOrderItem(orderItemVo, customerId);
            price = price + price_temp;
            cost = cost_temp + cost;
        }
        float profit = price - cost;
        OrderVo orderVo = new OrderVo(0, goods, date, date, price, customerId, profit);
        orderMapper.add(orderVo);
    }

    public void modify(String goods, int customerId, int id){
        Date modifyDate = new Date();
        float price = 0;
        float cost = 0;
        List<Integer> aList = Utils.getItemsIdFromGoods(goods);
        for(Integer i : aList){
            OrderItemVo orderItemVo = orderItemMapper.getById(i);
            float price_temp = getPriceOfOrderItem(orderItemVo, customerId);
            float cost_temp = getCostOfOrderItem(orderItemVo, customerId);
            price = price + price_temp;
            cost = cost_temp + cost;
        }
        float profit = price - cost;
        OrderVo last = orderMapper.getById(id);
        Date date = last.getCreateDate();
        OrderVo orderVo = new OrderVo(id, goods, date, modifyDate, price, customerId, profit);
        orderMapper.modify(orderVo);
    }

    public void confirm(int id){
        //System.out.println(1);
        OrderVo orderVo = orderMapper.getById(id);
        String goods = orderVo.getGoods();
        float price = orderVo.getPrice();
        int customerId = orderVo.getCustomerId();
        float profit = orderVo.getProfit();
        orderMapper.remove(id);
        DraftOrderVo draftOrderVo = new DraftOrderVo(0, new Date(), 0, 0, goods, price, customerId, profit);
        draftOrderMapper.add(draftOrderVo);
    }

    public List<OrderVo> getAll(){
        return orderMapper.getAll();
    }

    public void remove(int id){
        orderMapper.remove(id);
    }

    public OrderVo getById(int id){
        return orderMapper.getById(id);
    }

    public static float getPriceOfOrderItem(OrderItemVo orderItemVo, int customerId){

        int goodsId = orderItemVo.getGoodsId();
        Goods goods = goodsMapper.getById(goodsId);
        Customer customer = customerMapper.getById(customerId);
        float price = 0;
        if(customer.isMethod()){
            price = goods.getTradePrice();
        }else {
            price = goods.getPrice();
        }
        return orderItemVo.getNum()*price*orderItemVo.getDiscountRate();
    }

    public static float getCostOfOrderItem(OrderItemVo orderItemVo, int customerId){

        int goodsId = orderItemVo.getGoodsId();
        Goods goods = goodsMapper.getById(goodsId);
        return orderItemVo.getNum()*goods.getCost();
    }

}
