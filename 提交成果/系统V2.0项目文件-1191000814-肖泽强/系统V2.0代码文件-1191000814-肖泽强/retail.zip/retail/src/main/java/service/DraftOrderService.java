package service;

import mapper.DraftOrderMapper;
import pojo.DraftOrderVo;
import utils.MyBatisUtils;

import java.util.List;

public class DraftOrderService {

    DraftOrderMapper mapper = MyBatisUtils.getSqlSession().getMapper(DraftOrderMapper.class);

    public void addDraftOrder(DraftOrderVo draftOrderVo){
        draftOrderVo.setId(mapper.getMaxId() + 1);
        mapper.add(draftOrderVo);
    }

    public DraftOrderVo getById(int id){
        return mapper.getById(id);
    }

    public void remove(int id){
        mapper.remove(id);
    }

    public void pay(int id){
        DraftOrderVo draftOrderVo = mapper.getById(id);
        draftOrderVo.setPay(1);
        mapper.modify(draftOrderVo);
    }

    public void refund(int id){
        DraftOrderVo draftOrderVo = mapper.getById(id);
        draftOrderVo.setRefund(1);
        mapper.modify(draftOrderVo);
    }

    public List<DraftOrderVo> getAll(){
        return mapper.getAll();
    }

}
