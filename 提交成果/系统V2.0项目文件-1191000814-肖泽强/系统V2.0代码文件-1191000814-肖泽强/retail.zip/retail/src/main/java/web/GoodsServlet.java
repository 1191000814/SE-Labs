package web;

import com.google.gson.Gson;
import pojo.Goods;
import pojo.Result;
import service.GoodsService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class GoodsServlet extends BaseServlet{

    GoodsService goodsService = new GoodsService();
    Gson gson = new Gson();

    public void search(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        System.out.println("接收到的数据: " + data);
        Goods goods = gson.fromJson(data, Goods.class);
        System.out.println("查询商品名称: " + goods.getName());
        List<Goods> infos;
        if(goods.getName().equals("*"))
            infos = goodsService.getAll();
        else
            infos = goodsService.search(goods.getName());
        boolean flag = infos.size() > 0;
        resp.getWriter().write(Result.resJson(flag, flag ? infos : "没有查询到任何结果"));
    }

    public void getAll(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        List<Goods> infos = goodsService.getAll();
        boolean flag = infos.size() > 0;
        resp.getWriter().write(Result.resJson(flag, flag ? infos : "仓库里没有任何商品"));
    }

    public void add(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        System.out.println("接收到数据:" + data);
        Goods goods = gson.fromJson(data, Goods.class);
        boolean flag = goodsService.add(goods);
        if(flag)
            System.out.println("成功添加: " + goods.getName());
        resp.getWriter().write(Result.resJson(flag, flag ? null : "添加失败, 已经有相同的商品"));
    }

    public void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        System.out.println("接收到的数据: " + data);
        Goods goods = gson.fromJson(data, Goods.class);
        boolean flag = true;
        try{
            goodsService.delete(goods.getId());
        }catch(Exception e){
            // 如果由于外键约束无法删除
            flag = false;
            System.out.println("由于外键约束, 无法删除" + goods.getName());
        }
        resp.getWriter().write(Result.resJson(flag, flag ? null : "仓库中已经有该种货品, 无法删除"));
    }

    public void update(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        System.out.println("接收到的数据: " + data);
        Goods goods = gson.fromJson(data, Goods.class);
        boolean flag = goodsService.update(goods);
        resp.getWriter().write(Result.resJson(flag, flag ? null : "修改失败"));
    }
}