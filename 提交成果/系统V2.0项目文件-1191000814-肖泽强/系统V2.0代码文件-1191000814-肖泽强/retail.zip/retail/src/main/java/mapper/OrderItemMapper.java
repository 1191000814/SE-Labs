package mapper;

import pojo.OrderItemVo;
import java.util.List;

public interface OrderItemMapper{

    void add(OrderItemVo orderItemVo);

    void remove(int id);

    void modify(OrderItemVo orderItemVo);

    OrderItemVo getById(int id);

    List<OrderItemVo> getAll();

    int getMaxId();
}