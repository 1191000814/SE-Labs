package pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderVo {

    private int id;
    private String goods;
    private Date createDate;
    private Date imDate;
    private float price;
    private int customerId;
    private float profit;
}