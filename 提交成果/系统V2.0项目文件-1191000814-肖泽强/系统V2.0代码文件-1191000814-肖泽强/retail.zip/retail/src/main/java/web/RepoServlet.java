package web;

import com.google.gson.Gson;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pojo.RepoInfo;
import pojo.Result;
import service.GoodsService;
import service.RepoService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RepoServlet extends BaseServlet{

    RepoService repoService = new RepoService();
    Gson gson = new Gson();

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    static class FSearch{
        private String goodsName;
        private String repoId;
    }

    // 向后端返回数据的内部类
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    static class RepoInfo2{
        private int goodsId;
        private String goodsName;
        private int goodsNum;
        private int repoId;
    }

    public void search(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        System.out.println(req.getParameter("data"));
        FSearch fSearch = gson.fromJson(req.getParameter("data"), FSearch.class);
        System.out.println(fSearch);
        String pattern = fSearch.goodsName;
        String ids = fSearch.repoId;
        int repoIds = Integer.parseInt(ids.substring(0, 1)) * 4 + Integer.parseInt(ids.substring(1, 2)) * 2 + Integer.parseInt(ids.substring(2, 3));
        System.out.println("搜索的仓库:" + repoIds);
        System.out.println("搜索的字符串: " + pattern);
        List<RepoInfo> infos;
        if(pattern.equals("")) // 查询所有
            infos = repoService.getAll(repoIds); // 原RepoInfo仓库类(不含名称)
        else
            infos = repoService.search(fSearch.goodsName, repoIds); // 原RepoInfo仓库类(不含名称)
        List<RepoInfo2> info2s = getRepoInfo2s(infos); // 这才是要返回前端的类
        boolean flag = info2s.size() > 0;
        resp.getWriter().write(Result.resJson(flag, flag ? info2s : "没有查询到任何结果"));
    }

    public void getAll(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        FSearch fSearch = gson.fromJson(req.getParameter("data"), FSearch.class);
        System.out.println("要查询全部的仓库:" + req.getParameter("data"));
        String ids = fSearch.repoId;
        int repoIds = Integer.parseInt(ids.substring(0, 1)) * 4 + Integer.parseInt(ids.substring(1, 2)) * 2 + Integer.parseInt(ids.substring(2, 3));
        List<RepoInfo> infos = repoService.getAll(repoIds);
        List<RepoInfo2> info2s = getRepoInfo2s(infos);
        boolean flag = info2s.size() > 0;
        resp.getWriter().write(Result.resJson(flag, flag ? info2s : "仓库里没有任何商品"));
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    static class FDispatch{
        private int oldRepo;
        private int newRepo;
        private int goodsId;
        private int goodsNum;
    }

    public void dispatch(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String data = req.getParameter("data");
        FDispatch fDispatch = gson.fromJson(data, FDispatch.class);
        boolean flag = repoService.dispatch(fDispatch.oldRepo,fDispatch.newRepo, fDispatch.goodsId, fDispatch.goodsNum);
        resp.getWriter().write(Result.resJson(flag, flag ? null : "转移失败, 没有足够多的货物"));
    }

    // 私有方法,仅在类中调用
    private List<RepoInfo2> getRepoInfo2s(List<RepoInfo> infos){
        List<RepoInfo2> info2s = new ArrayList<>(); // 要返回的类(含名称)
        GoodsService goodsService = new GoodsService();
        for(RepoInfo info : infos){
            // 把info中的信息都加到info2中, 还有一个name
            RepoInfo2 info2 = new RepoInfo2();
            info2.setGoodsId(info.getGoodsId());
            info2.setGoodsNum(info.getGoodsNum());
            info2.setRepoId(info.getRepoId());
            info2.setGoodsName(goodsService.getById(info.getGoodsId()).getName());
            info2s.add(info2); // 记得加到info2的集合中
        }
        return info2s;
    }
}