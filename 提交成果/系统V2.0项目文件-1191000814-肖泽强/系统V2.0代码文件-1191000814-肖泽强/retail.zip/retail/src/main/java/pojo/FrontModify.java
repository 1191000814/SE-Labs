package pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FrontModify {

    private int id;
    private List<FrontAddItem> goodItems;
    private int customerId;
}
