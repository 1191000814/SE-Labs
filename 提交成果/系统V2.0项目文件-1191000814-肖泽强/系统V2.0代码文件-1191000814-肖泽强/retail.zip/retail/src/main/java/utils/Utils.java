package utils;

import mapper.OrderItemMapper;
import pojo.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class Utils {

    private static final OrderItemMapper orderItemMapper = MyBatisUtils.getSqlSession().getMapper(OrderItemMapper.class);

    // 将字符串解析成日期
    public static String dateToString(Date date){
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }

    // 将日期转化成字符串
    public static Date stringToDate(String str) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            return sdf.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 从goods字符串中解析出orderItem的id列表
    public static List<Integer> getItemsIdFromGoods(String goods){
        String[] aStrings = goods.split(" ");
        List<Integer> aList = new ArrayList<>();
        for(String item : aStrings){
            int id = Integer.parseInt(item);
            aList.add(id);
        }
        return aList;
    }

    public static FrontOrder orderTran(OrderVo orderVo){
        FrontOrder frontOrder = new FrontOrder();
        List<OrderItemVo> orderItemVos = new ArrayList<>();

        frontOrder.setId(orderVo.getId());
        frontOrder.setCreateDate(orderVo.getCreateDate());
        frontOrder.setCustomerId(orderVo.getCustomerId());
        frontOrder.setPrice(orderVo.getPrice());
        frontOrder.setImDate(orderVo.getImDate());
        frontOrder.setProfit(orderVo.getProfit());

        List<Integer> orderItemIdList = getItemsIdFromGoods(orderVo.getGoods());
        for(Integer a : orderItemIdList){
            OrderItemVo orderItemVo = orderItemMapper.getById(a);
            orderItemVos.add(orderItemVo);
        }
        frontOrder.setGoods(orderItemVos);

        return frontOrder;

    }

    public static List<FrontOrder> ordersTran(List<OrderVo> aList){
        List<FrontOrder> bList = new ArrayList<>();
        for(OrderVo order: aList){
            bList.add(orderTran(order));
        }
        return bList;
    }


    public static FrontDraftOrder draftOrderTran(DraftOrderVo draftOrderVo){
        FrontDraftOrder frontDraftOrder = new FrontDraftOrder();
        List<OrderItemVo> orderItemVos = new ArrayList<>();

        frontDraftOrder.setId(draftOrderVo.getId());
        frontDraftOrder.setCheckDate(draftOrderVo.getCheckDate());
        frontDraftOrder.setCustomerId(draftOrderVo.getCustomerId());
        frontDraftOrder.setPrice(draftOrderVo.getPrice());
        frontDraftOrder.setPay(draftOrderVo.getPay());
        frontDraftOrder.setProfit(draftOrderVo.getProfit());
        frontDraftOrder.setRefund(draftOrderVo.getRefund());

        List<Integer> orderItemIdList = getItemsIdFromGoods(draftOrderVo.getGoods());
        for(Integer a : orderItemIdList){
            OrderItemVo orderItemVo = orderItemMapper.getById(a);
            orderItemVos.add(orderItemVo);
        }
        frontDraftOrder.setGoods(orderItemVos);

        return frontDraftOrder;

    }

    public static List<FrontDraftOrder> draftOrdersTran(List<DraftOrderVo> aList){
        List<FrontDraftOrder> bList = new ArrayList<>();
        for(DraftOrderVo draftOrderVo : aList){
            bList.add(draftOrderTran(draftOrderVo));
        }
        return bList;
    }

}
