package mapper;

import pojo.DraftOrderVo;
import java.util.List;

public interface DraftOrderMapper{

    // 添加一个草稿单
    void add(DraftOrderVo draftOrderVo);

    // 按id删除草稿单
    void remove(int id);

    // 按id修改草稿单
    void modify(DraftOrderVo draftOrderVo);

    // 按id获取
    DraftOrderVo getById(int id);

    // 按顾客id获取草稿单
    DraftOrderVo getByCustomer(int customerId);

    // 获取所有草稿单
    List<DraftOrderVo> getAll();

    int getMaxId();
}
