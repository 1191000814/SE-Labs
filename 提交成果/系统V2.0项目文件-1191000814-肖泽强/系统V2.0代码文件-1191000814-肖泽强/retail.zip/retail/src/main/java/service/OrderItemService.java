package service;

import mapper.OrderItemMapper;
import pojo.OrderItemVo;
import utils.MyBatisUtils;

public class OrderItemService {

    OrderItemMapper mapper = MyBatisUtils.getSqlSession().getMapper(OrderItemMapper.class);

    // 增加订单项并返回它的id
    public int add(int goodsId, String goodsName, int num, float discountRate){
        //System.out.println(goodsId);
        mapper.add(new OrderItemVo(0, goodsId, goodsName, num, discountRate));
        System.out.println();
        return mapper.getMaxId();
    }
}
