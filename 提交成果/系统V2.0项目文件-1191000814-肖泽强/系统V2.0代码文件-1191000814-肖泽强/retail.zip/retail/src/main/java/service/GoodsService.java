package service;

import mapper.GoodsMapper;
import pojo.Goods;
import utils.MyBatisUtils;

import java.util.List;

public class GoodsService{
    
    public GoodsMapper goodsMapper = MyBatisUtils.getSqlSession().getMapper(GoodsMapper.class);

    public boolean add(Goods goods){
        // 先检查是否商品是否已经存在(不区分大小写)
        if(goods == null)
            return false;
        Goods byFullName = goodsMapper.getByFullName(goods.getName());
        if(byFullName != null)
            return false;
        int maxId = goodsMapper.getMaxId();
        goods.setId(maxId + 1);
        return goodsMapper.insert(goods) > 0;
    }

    public boolean update(Goods goods){
        if(goods == null)
            return false;
        return goodsMapper.updateById(goods) > 0;
    }

    public List<Goods> search(String pattern){
        return goodsMapper.getByName("%" + pattern + "%");
    }

    public List<Goods> getAll(){
        return goodsMapper.getAll();
    }

    public boolean delete(int id){
        return goodsMapper.deleteById(id) > 0;
    }

    public Goods getById(int id){
        return goodsMapper.getById(id);
    }
}