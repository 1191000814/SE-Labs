package pojo;

import com.google.gson.reflect.TypeToken;

public class ResultType extends TypeToken<Result>{
}