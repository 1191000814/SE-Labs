package service;

import mapper.UserMapper;
import pojo.User;
import utils.MyBatisUtils;

import java.util.List;

public class UserService{

    UserMapper userMapper = MyBatisUtils.getSqlSession().getMapper(UserMapper.class);

    public User register(User user){
        // 先检查是否用户名已经存在(不区分大小写)
        if(userMapper.getByFullName(user.getUsername()) != null)
            return null;
        int maxId = userMapper.getMaxId();
        user.setId(maxId + 1);
        userMapper.insert(user);
        return user;
    }

    public User login(String username, String password){
        if(username == null || password == null)
            return null;
        return userMapper.getByNameAndPassword(username, password);
    }

    public List<User> getAllCustomer(){
        return userMapper.getAllCustomer();
    }

    // 按名字模糊查询
    public List<User> getByName(String username){
        return userMapper.getByName("%" + username + "%");
    }

    public void deleteCustomerById(int id){

    }
}