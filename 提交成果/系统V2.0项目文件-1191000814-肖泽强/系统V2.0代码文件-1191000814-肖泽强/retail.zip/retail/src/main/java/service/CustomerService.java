package service;

import lombok.SneakyThrows;
import mapper.CustomerMapper;
import pojo.Customer;
import utils.MyBatisUtils;

import java.util.List;

public class CustomerService{

    CustomerMapper customerMapper = MyBatisUtils.getSqlSession().getMapper(CustomerMapper.class);

    @SneakyThrows
    public boolean add(Customer customer){
        if(customer == null)
            return false;
        int maxId = customerMapper.getMaxId();
        customer.setId(maxId + 1);
        customerMapper.insert(customer);
        return true;
    }

    // 注意这里name不能修改
    public boolean update(Customer customer){
        if(customer == null)
            return false;
        return customerMapper.updateById(customer) > 0;
    }

    public boolean delete(int id){
        return customerMapper.deleteById(id) > 0;
    }

    public List<Customer> search(String pattern){
        return customerMapper.getByName("%" + pattern + "%");
    }

    public List<Customer> getAll(){
        return customerMapper.getAll();
    }
}
