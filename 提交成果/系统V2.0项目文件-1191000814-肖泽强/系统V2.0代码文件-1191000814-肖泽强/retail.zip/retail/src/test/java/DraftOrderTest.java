import mapper.DraftOrderMapper;
import org.junit.Test;
import service.DraftOrderService;
import utils.MyBatisUtils;

public class DraftOrderTest{

    static DraftOrderMapper mapper = MyBatisUtils.getSqlSession().getMapper(DraftOrderMapper.class);
    DraftOrderService service = new DraftOrderService();

    @Test
    public void test(){
    }

    @Test
    public void test1(){
    }

    @Test
    public void test2(){
    }
}
