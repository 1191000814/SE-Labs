import com.google.gson.Gson;
import org.junit.Test;
import pojo.User;

import java.util.Date;

public class JsonTest{

    Gson gson = new Gson();

    @Test
    public void test(){
        User user = new User(1, "xzq", "020111", "wer", 3);
        String s = gson.toJson(user);
        System.out.println(s);
        User user1 = gson.fromJson(s, User.class);
        System.out.println(user1);
        System.out.println(user1.equals(user));
    }

    @Test
    public void test1(){
        String s = "{'id':1,'username':'xzq','password':'020111'}";
        User user = gson.fromJson(s, User.class);
        System.out.println(user);
    }

    @Test
    public void test3(){
        System.out.println(1 & 2);
    }
}
